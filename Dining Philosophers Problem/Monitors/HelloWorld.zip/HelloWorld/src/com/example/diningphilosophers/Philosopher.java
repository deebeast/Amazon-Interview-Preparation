package com.example.diningphilosophers;

import com.example.diningphilosophers.PhilosopherState.States;

class Philosopher {
    private States state;
    private boolean alreadyInQueue;

    Philosopher() {
        state = States.THINKING;
        alreadyInQueue = false;
    }

    boolean isAlreadyInQueue() {
        return alreadyInQueue;
    }

    void setAlreadyInQueue(boolean alreadyInQueue) {
        this.alreadyInQueue = alreadyInQueue;
    }

    States getState() {
        return state;
    }

    void setState(States state) {
        this.state = state;
    }
}