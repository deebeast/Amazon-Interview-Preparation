package com.example.diningphilosophers;

class PhilosopherState {
    enum States {
        HUNGRY, THINKING, EATING
    }
}
