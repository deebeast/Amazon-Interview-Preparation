package com.example.diningphilosophers;

//Refer OS by Galvin

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import com.example.diningphilosophers.PhilosopherState.States;


class Test {
    private static Philosopher[] p = new Philosopher[5];
    private static int max = 5;

    private static void pickup(int i) {
        if (p[i].isAlreadyInQueue()) {
            System.out.println("p[" + i + "] Already in queue !");
            return;
        }
        p[i].setState(States.HUNGRY);
        test(i);
    }

    private static void putsdown(int i) {
        if (!States.EATING.equals(p[i].getState())) {
            System.out.println("p[" + i + "] is not Eating.");
            System.out.println("p[" + i + "] is in " + p[i].getState() + " state");
            return;
        }
        p[i].setState(States.THINKING);
        p[i].setAlreadyInQueue(false);
        System.out.println("p[" + i + "] has put down forks");
        if (States.HUNGRY.equals(p[(i + 4) % 5].getState())) test((i + 4) % 5);
        if (States.HUNGRY.equals(p[(i + 1) % 5].getState())) test((i + 1) % 5);
    }

    private static void test(int i) {
        if (!States.EATING.equals(p[(i + 4) % 5].getState()) && States.HUNGRY.equals(p[i].getState()) && !(States.EATING.equals(p[(i + 1) % 5].getState()))) {
            p[i].setState(States.EATING);
            p[i].setAlreadyInQueue(true);
            System.out.println("p[" + i + "] is eating");
        } else System.out.println("p[" + i + "] can't eat at the moment");
    }

    public static void main(String[] args) throws IOException {
        System.out.println("-------------------------");
        System.out.println("The program has started..");
        System.out.println("-------------------------");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        for (int i = 0; i < 5; i++) p[i] = new Philosopher();
        String command;
        String[] temp;
        int pid;
        while (true) {
            temp = br.readLine().trim().split(" ");
            command = temp[0];
            pid = Integer.parseInt(temp[1]);
            if (pid < max) {
                if (command.equals("eat")) pickup(pid);
                else if (command.equals("end")) putsdown(pid);
            } else System.out.println("philosopher not present");
        }
    }
}
