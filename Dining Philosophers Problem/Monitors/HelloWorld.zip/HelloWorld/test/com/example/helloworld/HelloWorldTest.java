package com.example.helloworld;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HelloWorldTest {
    private HelloWorld hw;

    @Before
    public void setUp() {
        hw = new HelloWorld();
    }

    @After
    public void tearDown() {
        hw = null;
    }

    @Test
    public void main() {
        assert (hw != null);
    }

    @Test
    public void main2() {
        assert (hw instanceof HelloWorld);
    }

    @Test
    public void main3() {
        assert (hw.getClass() != HelloWorld.class);
    }
}
